import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <p>ЦОДД Смоленской области © 2025</p>
            </div>
        </footer>
    );
};

export default Footer;
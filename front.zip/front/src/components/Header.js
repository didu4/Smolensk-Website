import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Header = () => {

    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);

    const searchSuggestions = [
    'Дорожное движение',
    'Светофоры',
    'Парковка',
    'Дорожные знаки',
    'Проекты благоустройства',
    'Правила дорожного движения',
    'Дорожная разметка',
    'Безопасность дорожного движения',
    'Транспортные потоки',
    'Ремонт дорог',
    'Строительство дорог',
    'Общественный транспорт',
    'Велосипедные дорожки',
    'Пешеходные переходы',
    'Эвакуация автомобилей',
    'Дорожные камеры',
    'Пробки и заторы',
    'Дорожные работы',
    'Ограничение движения',
    'Знаки остановки'
    ];
    const [searchResults, setSearchResults] = useState([]);
    React.useEffect(() => {
        if (searchQuery.length > 2) {
        const results = searchSuggestions.filter(suggestion =>
            suggestion.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setSearchResults(results);
        setShowSuggestions(true);
        } else {
        setShowSuggestions(false);
        }
    }, [searchQuery]);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    const handleSuggestionClick = (suggestion) => {
        setSearchQuery(suggestion);
        setShowSuggestions(false);
        // Здесь можно добавить логику поиска по выбранной подсказке
        console.log('Поиск по:', suggestion);
    };

    const handleSearchSubmit = (e) => {
        if (e.key === 'Enter') {
        e.preventDefault();
        // Логика выполнения поиска
        console.log('Выполняем поиск:', searchQuery);
        setShowSuggestions(false);
        }
    };

    return (
        <header className="header">
            <div className="container">
                <div className="header-content">
                    <Link to="/" className="logo">
                        <div className="logo-icon">ЦОДД</div>
                        <div className="logo-text">
                            <div className="logo-title">Центр организации</div>
                            <div className="logo-title">дорожного движения</div>
                            {/* <div className="logo-subtitle">Смоленской области</div> */}
                        </div>
                    </Link>
                    {/* Кнопка меню для мобильных */}
                    <button className="nav-toggle" onClick={toggleMenu}>
                        ☰
                    </button>

                    {/* Основная навигация */}
                <nav className={`nav-menu ${isMenuOpen ? 'active' : ''}`}>
                    <Link to="/" className="nav-link" onClick={() => setIsMenuOpen(false)}>Главная</Link>
                    <Link to="/about" className="nav-link" onClick={() => setIsMenuOpen(false)}>О нас</Link>
                    <Link to="/team" className="nav-link" onClick={() => setIsMenuOpen(false)}>Команда</Link>
                    <Link to="/projects" className="nav-link" onClick={() => setIsMenuOpen(false)}>Проекты</Link>
                    <Link to="/news" className="nav-link" onClick={() => setIsMenuOpen(false)}>Новости</Link>
                    <Link to="/documents" className="nav-link" onClick={() => setIsMenuOpen(false)}>Документы</Link>
                    <Link to="/vacancies" className="nav-link" onClick={() => setIsMenuOpen(false)}>Вакансии</Link>
                    <Link to="/services" className="nav-link" onClick={() => setIsMenuOpen(false)}>Услуги</Link>
                    <Link to="/contacts" className="nav-link" onClick={() => setIsMenuOpen(false)}>Контакты</Link>
                    <Link to="/login" className="nav-link login-link" onClick={() => setIsMenuOpen(false)}>Войти</Link>
                </nav>

                {/* Поисковая строка */}
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Поиск по сайту..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => searchQuery.length > 2 && setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              onKeyPress={handleSearchSubmit}
            />
            
                    {/* Выпадающие подсказки */}
                    {showSuggestions && searchResults.length > 0 && (
                    <div className="search-suggestions">
                        {searchResults.map((result, index) => (
                        <div 
                            key={index} 
                            className="suggestion-item"
                            onMouseDown={() => handleSuggestionClick(result)}
                        >
                            {/* <span className="suggestion-icon">🔍</span> */}
                            {result}
                        </div>
                        ))}
                    </div>
                    )}
                </div>
                
                </div>
            </div>
        </header>
    );
};

export default Header;
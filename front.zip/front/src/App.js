import React, { useState, useEffect, lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Loading from './components/Loading';
import './App.css';
import './admin/styles/admin.css';

// Ленивая загрузка страниц для оптимизации
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Team = lazy(() => import('./pages/Team'));
const Projects = lazy(() => import('./pages/Projects'));
const News = lazy(() => import('./pages/News'));
const Documents = lazy(() => import('./pages/Documents'));
const Vacancies = lazy(() => import('./pages/Vacancies'));
const Contacts = lazy(() => import('./pages/Contacts'));
const Services = lazy(() => import('./pages/Services'));
const Login = lazy(() => import('./pages/Login'));
const AdminDashboard = lazy(() => import('./admin/pages/adminDashboard'));
const Statistics = lazy(() => import('./admin/pages/Statistics'));
const ContentEditor = lazy(() => import('./admin/pages/contentEditor'));
const Analytics = lazy(() => import('./admin/pages/Analytics'));
const ProtectedRoute = lazy(() => import('./admin/components/protectedRoute'));
const Files = lazy(() => import('./admin/pages/Files'));

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Имитация поисковых подсказок
  const searchSuggestions = [
    'Дорожное движение',
    'Светофоры',
    'Парковка',
    'Дорожные знаки',
    'Проекты благоустройства',
    'Правила дорожного движения'
  ];

  useEffect(() => {
    if (searchQuery.length > 2) {
      const results = searchSuggestions.filter(suggestion =>
        suggestion.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSearchResults(results);
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  }, [searchQuery]);

  return (
    <Router>
      <div className="App">
        <Header 
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          searchResults={searchResults}
          showSuggestions={showSuggestions}
          setShowSuggestions={setShowSuggestions}
        />
        <main className="main-content">
          <Suspense fallback={<Loading />}>
            <Routes>
  {/* Основные маршруты сайта */}
  <Route path="/" element={<Home />} />
  <Route path="/about" element={<About />} />
  <Route path="/team" element={<Team />} />
  <Route path="/projects" element={<Projects />} />
  <Route path="/news" element={<News />} />
  <Route path="/documents" element={<Documents />} />
  <Route path="/vacancies" element={<Vacancies />} />
  <Route path="/contacts" element={<Contacts />} />
  <Route path="/services" element={<Services />} />
  <Route path="/login" element={<Login />} /> {/* Обычная страница входа */}
  
  {/* Маршруты админ-панели */}
  <Route path="/admin/dashboard" element={
    <ProtectedRoute>
      <AdminDashboard />
    </ProtectedRoute>
  } />
  <Route path="/admin/statistics" element={
    <ProtectedRoute>
      <Statistics />
    </ProtectedRoute>
  } />
  <Route path="/admin/editor" element={
    <ProtectedRoute>
      <ContentEditor />
    </ProtectedRoute>
  } />
  <Route path="/admin/analytics" element={
    <ProtectedRoute>
      <Analytics />
    </ProtectedRoute>
  } />
  <Route path="/admin/files" element={
  <ProtectedRoute>
    <Files />
  </ProtectedRoute>
  } />
</Routes>
          </Suspense>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
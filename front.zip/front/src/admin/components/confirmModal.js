import React from 'react';

const ConfirmModal = ({ isOpen, onClose, onConfirm, title, message }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content modal-small">
        <div className="modal-header">
          <h3>{title}</h3>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <p>{message}</p>
          <div className="modal-actions">
            <button className="btn btn-secondary" onClick={onClose}>Нет</button>
            <button className="btn btn-danger" onClick={onConfirm}>Да</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
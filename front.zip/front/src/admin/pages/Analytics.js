import React, { useState } from 'react';

const Analytics = () => {
  const [selectedTables, setSelectedTables] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [predictionDays, setPredictionDays] = useState(30);
  const [activeTab, setActiveTab] = useState('tables');

  const availableTables = [
    { id: 1, name: 'ДТП_2024', columns: ['Дата', 'Район', 'Тип ДТП', 'Пострадавшие'] },
    { id: 2, name: 'Трафик_2024', columns: ['Дата', 'Улица', 'Интенсивность'] }
  ];

  const availableFiles = [
    { id: 1, name: 'Анализ_пробок_2024.xlsx', type: 'excel', records: 1500 },
    { id: 2, name: 'Статистика_ремонтов.pdf', type: 'pdf', records: 300 },
    { id: 3, name: 'Данные_с_камер.csv', type: 'excel', records: 5000 }
  ];

  return (
    <div className="admin-page">
      <div className="page-header">
        <h1>Платформа аналитики</h1>
      </div>

      <div className="analytics-grid">
        {/* Левая панель - источники данных */}
        <div className="analytics-sidebar">
          <div className="data-sources-tabs">
            <button 
              className={`tab-button ${activeTab === 'tables' ? 'active' : ''}`}
              onClick={() => setActiveTab('tables')}
            >
              📊 Таблицы БД
            </button>
            <button 
              className={`tab-button ${activeTab === 'files' ? 'active' : ''}`}
              onClick={() => setActiveTab('files')}
            >
              📁 Файлы
            </button>
          </div>

          {activeTab === 'tables' && (
            <div className="tables-section">
              <h3>Таблицы базы данных</h3>
              {availableTables.map(table => (
                <div key={table.id} className="data-item">
                  <input 
                    type="checkbox"
                    checked={selectedTables.includes(table.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedTables([...selectedTables, table.id]);
                      } else {
                        setSelectedTables(selectedTables.filter(id => id !== table.id));
                      }
                    }}
                  />
                  <span>{table.name}</span>
                  <small>{table.columns.length} колонок</small>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'files' && (
            <div className="files-section">
              <h3>Загруженные файлы</h3>
              {availableFiles.map(file => (
                <div key={file.id} className="data-item">
                  <input 
                    type="checkbox"
                    checked={selectedFiles.includes(file.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedFiles([...selectedFiles, file.id]);
                      } else {
                        setSelectedFiles(selectedFiles.filter(id => id !== file.id));
                      }
                    }}
                  />
                  <span>{file.name}</span>
                  <small>{file.records} записей</small>
                </div>
              ))}
            </div>
          )}

          <div className="prediction-section">
            <label>Прогноз на дней:</label>
            <input 
              type="number" 
              value={predictionDays}
              onChange={(e) => setPredictionDays(e.target.value)}
              min="1"
              max="365"
            />
          </div>

          <div className="action-buttons">
            <button className="btn btn-primary">Сравнить данные</button>
            <button className="btn btn-success">Визуализировать</button>
            <button className="btn btn-warning">Построить прогноз</button>
          </div>
        </div>

        {/* Основная область - визуализация */}
        <div className="analytics-main">
          <div className="data-visualization">
            <h3>Визуализация данных</h3>
            <div className="chart-placeholder">
              {(selectedTables.length > 0 || selectedFiles.length > 0) ? (
                <div>
                  <h4>Анализ выбранных данных:</h4>
                  <div className="selected-items">
                    {selectedTables.map(id => {
                      const table = availableTables.find(t => t.id === id);
                      return <span key={id} className="selected-tag">📊 {table?.name}</span>;
                    })}
                    {selectedFiles.map(id => {
                      const file = availableFiles.find(f => f.id === id);
                      return <span key={id} className="selected-tag">📁 {file?.name}</span>;
                    })}
                  </div>
                  <div className="chart-container">
                    <div style={{height: '300px', background: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                      График анализа данных
                    </div>
                  </div>
                </div>
              ) : (
                <p>Выберите таблицы или файлы для анализа</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
import React, { useState } from 'react';
import Modal from '../components/Modal';
import ConfirmModal from '../components/ConfirmModal';
import FileUploader from '../components/FileUploader';

const Files = () => {
  const [files, setFiles] = useState([
    { id: 1, name: 'Отчет_ДТП_2024.xlsx', type: 'excel', size: '2.4 МБ', date: '2024-01-15', category: 'Статистика' },
    { id: 2, name: 'План_дорожных_работ.pdf', type: 'pdf', size: '1.2 МБ', date: '2024-01-10', category: 'Проекты' },
    { id: 3, name: 'Фото_светофоров.zip', type: 'archive', size: '15.7 МБ', date: '2024-01-08', category: 'Документация' }
  ]);

  const [filters, setFilters] = useState({ category: '', type: '', dateFrom: '', dateTo: '' });
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [fileToDelete, setFileToDelete] = useState(null);

  const fileTypes = {
    excel: '📊',
    pdf: '📄',
    archive: '📦',
    image: '🖼️',
    word: '📝',
    other: '📎'
  };

  const filteredFiles = files.filter(file => 
    (!filters.category || file.category === filters.category) &&
    (!filters.type || file.type === filters.type) &&
    (!filters.dateFrom || file.date >= filters.dateFrom) &&
    (!filters.dateTo || file.date <= filters.dateTo)
  );

  const handleFileUpload = (file) => {
    const newFile = {
      id: files.length + 1,
      name: file.name,
      type: getFileType(file.name),
      size: formatFileSize(file.size),
      date: new Date().toISOString().split('T')[0],
      category: 'Общее'
    };
    setFiles([...files, newFile]);
    setIsUploadModalOpen(false);
    alert(`Файл "${file.name}" успешно загружен!`);
  };

  const getFileType = (fileName) => {
    const ext = fileName.split('.').pop().toLowerCase();
    if (['xlsx', 'xls', 'csv'].includes(ext)) return 'excel';
    if (['pdf'].includes(ext)) return 'pdf';
    if (['zip', 'rar', '7z'].includes(ext)) return 'archive';
    if (['jpg', 'jpeg', 'png', 'gif'].includes(ext)) return 'image';
    if (['doc', 'docx'].includes(ext)) return 'word';
    return 'other';
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Б';
    const k = 1024;
    const sizes = ['Б', 'КБ', 'МБ', 'ГБ'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleDelete = (file) => {
    setFileToDelete(file);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    setFiles(files.filter(f => f.id !== fileToDelete.id));
    setIsDeleteModalOpen(false);
    setFileToDelete(null);
  };

  return (
    <div className="admin-page">
      <div className="page-header">
        <h1>Управление файлами</h1>
        <button 
          className="btn btn-primary"
          onClick={() => setIsUploadModalOpen(true)}
        >
          📤 Загрузить файл
        </button>
      </div>

      <div className="filters-section">
        <select 
          value={filters.category} 
          onChange={(e) => setFilters({...filters, category: e.target.value})}
        >
          <option value="">Все категории</option>
          <option value="Статистика">Статистика</option>
          <option value="Проекты">Проекты</option>
          <option value="Документация">Документация</option>
          <option value="Отчеты">Отчеты</option>
        </select>

        <select 
          value={filters.type} 
          onChange={(e) => setFilters({...filters, type: e.target.value})}
        >
          <option value="">Все типы</option>
          <option value="excel">Excel</option>
          <option value="pdf">PDF</option>
          <option value="archive">Архивы</option>
          <option value="image">Изображения</option>
        </select>

        <input 
          type="date" 
          placeholder="От даты"
          value={filters.dateFrom}
          onChange={(e) => setFilters({...filters, dateFrom: e.target.value})}
        />

        <input 
          type="date" 
          placeholder="До даты"
          value={filters.dateTo}
          onChange={(e) => setFilters({...filters, dateTo: e.target.value})}
        />

        <button className="btn btn-secondary">Сбросить фильтры</button>
      </div>

      <div className="files-grid">
        {filteredFiles.map(file => (
          <div key={file.id} className="file-card">
            <div className="file-header">
              <span className="file-icon">{fileTypes[file.type]}</span>
              <div className="file-info">
                <h4>{file.name}</h4>
                <span className="file-category">{file.category}</span>
              </div>
            </div>
            
            <div className="file-details">
              <p>Размер: {file.size}</p>
              <p>Дата: {file.date}</p>
              <p>Тип: {file.type}</p>
            </div>

            <div className="file-actions">
              <button className="btn btn-sm btn-primary">Скачать</button>
              <button className="btn btn-sm btn-secondary">Просмотр</button>
              <button 
                className="btn btn-sm btn-danger"
                onClick={() => handleDelete(file)}
              >
                Удалить
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Модальное окно загрузки файла */}
      <Modal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)}
        title="Загрузка файла"
        size="medium"
      >
        <div className="upload-section">
          <FileUploader onFileUpload={handleFileUpload} />
          <div className="upload-info">
            <p><strong>Поддерживаемые форматы:</strong></p>
            <ul>
              <li>📊 Excel (.xlsx, .xls, .csv) - для табличных данных</li>
              <li>📄 PDF (.pdf) - для документов</li>
              <li>🖼️ Изображения (.jpg, .png) - для фотографий</li>
              <li>📦 Архивы (.zip, .rar) - для наборов файлов</li>
            </ul>
            <p><strong>Максимальный размер:</strong> 50 МБ</p>
          </div>
        </div>
      </Modal>

      {/* Модальное окно подтверждения удаления */}
      <ConfirmModal 
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDelete}
        title="Подтверждение удаления"
        message={`Вы уверены, что хотите удалить файл "${fileToDelete?.name}"?`}
      />
    </div>
  );
};

export default Files;
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (credentials.username === 'admin' && credentials.password === 'admin') {
      localStorage.setItem('isAdmin', 'true');
      navigate('/admin/dashboard');
    } else {
      alert('Неверные учетные данные');
    }
  };

  return (
    <div className="admin-login-page">
      <div className="login-container">
        <div className="login-form">
          <h2>Вход в админ-панель ЦОДД</h2>
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label>Логин:</label>
              <input
                type="text"
                value={credentials.username}
                onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                required
              />
            </div>
            <div className="form-group">
              <label>Пароль:</label>
              <input
                type="password"
                value={credentials.password}
                onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">Войти</button>
          </form>
          <p style={{marginTop: '20px', fontSize: '12px', color: '#666'}}>
            Логин: admin, Пароль: admin
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
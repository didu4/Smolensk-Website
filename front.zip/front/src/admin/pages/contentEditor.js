import React, { useState } from 'react';
import ConfirmModal from '../components/Modal';

const ContentEditor = () => {
  const [activeTab, setActiveTab] = useState('news');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);

  const contentData = {
    news: [
      { id: 1, title: 'Новые светофоры', date: '2024-01-15', status: 'Опубликовано' },
      { id: 2, title: 'Ремонт дорог', date: '2024-01-10', status: 'Черновик' }
    ],
    projects: [
      { id: 1, title: 'Реконструкция перекрестка', status: 'В работе' },
      { id: 2, title: 'Установка камер', status: 'Завершено' }
    ],
    team: [
      { id: 1, name: 'Иванов А.П.', position: 'Директор' }
    ]
  };

  const handleDelete = (item) => {
    setItemToDelete(item);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    // Логика удаления
    console.log('Удаляем:', itemToDelete);
    setIsDeleteModalOpen(false);
    setItemToDelete(null);
  };

  return (
    <div className="admin-page">
      <div className="page-header">
        <h1>Редактор контента</h1>
        <button className="btn btn-primary">+ Добавить новую</button>
      </div>

      <div className="tabs-section">
        <button 
          className={`tab-button ${activeTab === 'news' ? 'active' : ''}`}
          onClick={() => setActiveTab('news')}
        >
          Новости
        </button>
        <button 
          className={`tab-button ${activeTab === 'projects' ? 'active' : ''}`}
          onClick={() => setActiveTab('projects')}
        >
          Проекты
        </button>
        <button 
          className={`tab-button ${activeTab === 'team' ? 'active' : ''}`}
          onClick={() => setActiveTab('team')}
        >
          Команда
        </button>
      </div>

      <div className="content-list">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Название</th>
              <th>Дата</th>
              <th>Статус</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {contentData[activeTab].map(item => (
              <tr key={item.id}>
                <td>{item.title || item.name}</td>
                <td>{item.date || '-'}</td>
                <td>
                  <span className={`status-badge status-${item.status.toLowerCase()}`}>
                    {item.status}
                  </span>
                </td>
                <td>
                  <button className="btn btn-sm btn-primary">Редактировать</button>
                  <button 
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDelete(item)}
                  >
                    Удалить
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ConfirmModal 
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDelete}
        title="Подтверждение удаления"
        message="Вы уверены, что хотите удалить этот элемент?"
      />
    </div>
  );
};

export default ContentEditor;
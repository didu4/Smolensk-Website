import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('isAdmin');
    navigate('/'); // Перенаправляем на главную, а не на админ-логин
  };

  return (
    <div className="admin-dashboard">
      <div className="admin-header">
        <h1>Панель администратора ЦОДД</h1>
        <div className="admin-actions">
          <button className="btn btn-secondary" onClick={handleLogout}>Выйти</button>
        </div>
      </div>

      <div className="admin-grid">
        <Link to="/admin/statistics" className="admin-card">
          <div className="card-icon">📊</div>
          <h3>Публичная статистика</h3>
          <p>Управление публично доступной статистикой</p>
        </Link>

        <Link to="/admin/editor" className="admin-card">
          <div className="card-icon">📝</div>
          <h3>Редактор контента</h3>
          <p>Управление новостями, проектами, командой</p>
        </Link>

        <Link to="/admin/analytics" className="admin-card">
          <div className="card-icon">🔍</div>
          <h3>Платформа аналитики</h3>
          <p>Анализ данных и прогнозирование</p>
        </Link>

        <div className="admin-card">
          <div className="card-icon">👥</div>
          <h3>Пользователи</h3>
          <p>Управление пользователями и правами доступа</p>
        </div>

        <div className="admin-card">
          <div className="card-icon">⚙️</div>
          <h3>Настройки</h3>
          <p>Настройки системы и уведомлений</p>
        </div>

        <div className="admin-card">
          <div className="card-icon">📈</div>
          <h3>Отчеты</h3>
          <p>Генерация отчетов и аналитика</p>
        </div>

        <Link to="/admin/files" className="admin-card">
        <div className="card-icon">📁</div>
        <h3>Управление файлами</h3>
        <p>Загрузка и управление файлами системы</p>
      </Link>
      </div>
    </div>
  );
};

export default AdminDashboard;
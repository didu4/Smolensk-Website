import React, { useState } from 'react';
import Modal from '../components/Modal';
import ConfirmModal from '../components/ConfirmModal';

const Statistics = () => {
  const [statistics] = useState([
    { id: 1, name: 'Интенсивность движения', period: '2020-2024', type: 'Транспорт' },
    { id: 2, name: 'ДТП по районам', period: '2023-2024', type: 'Безопасность' },
    { id: 3, name: 'Загруженность дорог', period: '2024', type: 'Транспорт' }
  ]);

  const [filters, setFilters] = useState({ period: '', type: '' });
  const [selectedStats, setSelectedStats] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredStats = statistics.filter(stat => 
    (!filters.period || stat.period.includes(filters.period)) &&
    (!filters.type || stat.type === filters.type)
  );

  return (
    <div className="admin-page">
      <div className="page-header">
        <h1>Публичная статистика</h1>
        <button className="btn btn-primary">Добавить статистику</button>
      </div>

      <div className="filters-section">
        <select 
          value={filters.period} 
          onChange={(e) => setFilters({...filters, period: e.target.value})}
        >
          <option value="">Все периоды</option>
          <option value="2024">2024</option>
          <option value="2023">2023</option>
        </select>

        <select 
          value={filters.type} 
          onChange={(e) => setFilters({...filters, type: e.target.value})}
        >
          <option value="">Все типы</option>
          <option value="Транспорт">Транспорт</option>
          <option value="Безопасность">Безопасность</option>
        </select>

        <button 
          className="btn btn-secondary"
          onClick={() => setIsModalOpen(true)}
          disabled={selectedStats.length === 0}
        >
          Сравнить выбранное ({selectedStats.length})
        </button>

        <button className="btn btn-success">Скачать Excel</button>
      </div>

      <div className="data-grid">
        {filteredStats.map(stat => (
          <div key={stat.id} className="data-card">
            <input 
              type="checkbox"
              checked={selectedStats.includes(stat.id)}
              onChange={(e) => {
                if (e.target.checked) {
                  setSelectedStats([...selectedStats, stat.id]);
                } else {
                  setSelectedStats(selectedStats.filter(id => id !== stat.id));
                }
              }}
            />
            <h4>{stat.name}</h4>
            <p>Период: {stat.period}</p>
            <p>Тип: {stat.type}</p>
            <div className="card-actions">
              <button className="btn btn-sm btn-primary">Просмотр</button>
              <button className="btn btn-sm btn-secondary">Визуализация</button>
            </div>
          </div>
        ))}
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        title="Сравнение статистики"
        size="large"
      >
        <div className="comparison-view">
          <h4>Выбранные данные для сравнения:</h4>
          {selectedStats.map(id => {
            const stat = statistics.find(s => s.id === id);
            return <div key={id}>{stat?.name}</div>;
          })}
          <div className="visualization-placeholder">
            📊 Здесь будет график сравнения
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Statistics;
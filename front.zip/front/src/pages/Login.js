import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Проверка на админские credentials
    if (formData.email === 'admin' && formData.password === 'admin') {
      localStorage.setItem('isAdmin', 'true');
      navigate('/admin/dashboard');
      return;
    }
    
    // Обычная логика входа
    console.log('Обычный вход:', formData);
    alert('Форма отправлена!');
  };

  return (
    <div>
      <section className="hero" style={{background: 'linear-gradient(rgba(98, 167, 68, 0.8), rgba(98, 167, 68, 0.9))', padding: '60px 0'}}>
        <div className="container">
          <h1 className="hero-title">Вход в систему</h1>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div style={{maxWidth: '500px', margin: '0 auto'}}>
            <div style={{background: 'white', padding: '40px', borderRadius: '10px', boxShadow: '0 5px 15px rgba(0,0,0,0.1)'}}>
              <h2 style={{textAlign: 'center', marginBottom: '30px', color: '#2c3e50'}}>Авторизация</h2>
              
              <form onSubmit={handleSubmit}>
                <div style={{marginBottom: '20px'}}>
                  <label style={{display: 'block', marginBottom: '8px', fontWeight: '600'}}>Email или логин</label>
                  <input
                    type="text"
                    name="email"
                    style={{width: '100%', padding: '12px 15px', border: '2px solid #e0e0e0', borderRadius: '6px', fontSize: '16px'}}
                    placeholder="Введите ваш email или логин"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div style={{marginBottom: '20px'}}>
                  <label style={{display: 'block', marginBottom: '8px', fontWeight: '600'}}>Пароль</label>
                  <input
                    type="password"
                    name="password"
                    style={{width: '100%', padding: '12px 15px', border: '2px solid #e0e0e0', borderRadius: '6px', fontSize: '16px'}}
                    placeholder="Введите ваш пароль"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px'}}>
                  <label style={{display: 'flex', alignItems: 'center'}}>
                    <input
                      type="checkbox"
                      name="rememberMe"
                      checked={formData.rememberMe}
                      onChange={handleChange}
                      style={{marginRight: '8px'}}
                    />
                    Запомнить меня
                  </label>
                  
                  <a href="#forgot" style={{color: '#62a744', textDecoration: 'none', fontSize: '14px'}}>Забыли пароль?</a>
                </div>

                <button 
                  type="submit" 
                  style={{
                    width: '100%', 
                    background: 'linear-gradient(135deg, #62a744, #558b3d)',
                    color: 'white', 
                    border: 'none', 
                    padding: '14px',
                    borderRadius: '6px', 
                    fontSize: '16px', 
                    fontWeight: '600',
                    cursor: 'pointer'
                  }}
                >
                  Войти
                </button>

                <div style={{
                  background: '#fff3cd',
                  border: '1px solid #ffeaa7',
                  borderRadius: '5px',
                  padding: '15px',
                  marginTop: '20px',
                  fontSize: '14px'
                }}>
                  <p><strong>Для доступа к админ-панели:</strong></p>
                  <p>Логин: <code style={{background: '#f8f9fa', padding: '2px 6px', borderRadius: '3px'}}>admin</code></p>
                  <p>Пароль: <code style={{background: '#f8f9fa', padding: '2px 6px', borderRadius: '3px'}}>admin</code></p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Login;
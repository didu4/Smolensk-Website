import React from 'react';

const Services = () => {
    return (
        <div>
            <section className="hero" style={{background: 'linear-gradient(rgba(98, 167, 68, 0.8), rgba(98, 167, 68, 0.9))'}}>
                <div className="container">
                    <h1 className="hero-title">Услуги</h1>
                    {/* <p className="hero-subtitle">
                        Профессиональные решения для организации дорожного движения
                    </p> */}
                </div>
            </section>

            <section className="section">
                <div className="container">
                    <h2 className="section-title">Основные услуги</h2>
                    <div className="services-grid">
                        <div className="service-card">
                            <div className="service-icon">📋</div>
                            <h3>Разработка проектной документации</h3>
                            <p>Проектирование светофоров, дорожных знаков и разметки</p>
                            <div className="service-price">от 50 000 руб.</div>
                            <button className="service-button">Заказать</button>
                        </div>
                        
                        <div className="service-card">
                            <div className="service-icon">🚗</div>
                            <h3>Аренда автовышки</h3>
                            <p>Обслуживание дорожных объектов с использованием спецтехники</p>
                            <div className="service-price">от 5 000 руб/сутки</div>
                            <button className="service-button">Заказать</button>
                        </div>
                        
                        <div className="service-card">
                            <div className="service-icon">🚛</div>
                            <h3>Вызов эвакуатора</h3>
                            <p>Эвакуация транспортных средств, мешающих движению</p>
                            <div className="service-price">от 3 000 руб.</div>
                            <button className="service-button">Заказать</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Services;
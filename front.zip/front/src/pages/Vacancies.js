import React from 'react';

const Vacancies = () => {
  return (
    <div>
      <section className="hero" style={{background: 'linear-gradient(rgba(98, 167, 68, 0.8), rgba(98, 167, 68, 0.9))'}}>
        <div className="container">
          <h1 className="hero-title">Вакансии</h1>
        </div>
      </section>
      
      <section className="section">
        <div className="container">
          <h2 className="section-title">Работа в ЦОДД</h2>
          <p>Актуальные вакансии появятся скоро.</p>
        </div>
      </section>
    </div>
  );
};

export default Vacancies;
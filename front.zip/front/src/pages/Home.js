import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  const latestNews = [
    {
      id: 1,
      title: 'В Смоленске начали монтаж новых дорожных знаков в связи с изменением схемы движения',
      date: '24.09.2025',
      excerpt: 'Установка знаков проводится в соответствии с измененной схемой организации дорожного движения на одной из главных транспортных артерий Смоленска.'
    },
    {
      id: 2,
      title: 'Благодаря системе видеонаблюдения, установленной ЦОДД, оперативно выявлен и привлечен к административной ответственности водитель, грубо нарушивший правила дорожного движения в Смоленске',
      date: '01.08.2025',
      excerpt: 'Инцидент произошел на проспекте Гагарина, где водитель автомобиля, совершил разворот, игнорируя дорожную разметку.'
    },
    {
      id: 3,
      title: 'В Смоленске два дня подряд не будут работать светофторы',
      date: '21.07.2025',
      excerpt: 'О временных неудобствах в вечернее время предупредили в СОГБУ «Смоленскавтодор» со ссылкой на СОГБУ «ЦОДД».'
    }
  ];

  const services = [
    {
      id: 1,
      title: 'Проектирование дорожного движения',
      description: 'Разработка комплексных схем организации дорожного движения для новых районов и реконструируемых участков',
      price: 'от 75 000 руб.'
    },
    {
      id: 2,
      title: 'Техническое обслуживание светофоров',
      description: 'Круглосуточный мониторинг и обслуживание светофорных объектов по всему региону',
      price: 'от 20 000 руб./мес'
    }
  ];

  return (
    <div>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">Безопасные и комфортные дороги</h1>
          
          <Link to="/services" className="cta-button">Узнать о наших услугах</Link>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">О деятельности центра</h2>
          <div style={{textAlign: 'center', maxWidth: '900px', margin: '0 auto'}}>
            <p>
              <strong>Мы</strong> — ведущая организация в регионе, занимающаяся 
              комплексным решением вопросов организации дорожного движения. Наша миссия — создание безопасной, 
              эффективной и комфортной дорожной среды для всех категорий участников движения.
            </p>
            
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '30px', marginTop: '40px'}}>
              <div style={{textAlign: 'center', padding: '20px'}}>
                <div style={{fontSize: '48px', marginBottom: '15px'}}>🚦</div>
                <h3>300+ светофоров</h3>
                <p>Обслуживаем светофорные объекты по всей области</p>
              </div>
              
              <div style={{textAlign: 'center', padding: '20px'}}>
                <div style={{fontSize: '48px', marginBottom: '15px'}}>📊</div>
                <h3>24/7 мониторинг</h3>
                <p>Круглосуточный контроль дорожной ситуации</p>
              </div>
              
              <div style={{textAlign: 'center', padding: '20px'}}>
                <div style={{fontSize: '48px', marginBottom: '15px'}}>👥</div>
                <h3>Коллектив специалистов</h3>
                <p>Профессиональная команда экспертов</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <section className="section" style={{backgroundColor: '#f9f9f9'}}>
        <div className="container">
          <h2 className="section-title">Наши ключевые услуги</h2>
          <div className="services-grid">
            {services.map(service => (
              <div key={service.id} className="service-card">
                <div className="service-icon">🚦</div>
                <h3 className="service-title">{service.title}</h3>
                <p>{service.description}</p>
                <div className="service-price">{service.price}</div>
                <Link to="/services" className="service-button">Подробнее</Link>
              </div>
            ))}
          </div>
        </div>
      </section> */}

      <section className="section">
        <div className="container">
          <h2 className="section-title">Последние новости</h2>
          <div className="news-grid">
            {latestNews.map(news => (
              <div key={news.id} className="card">
                <div className="card-content">
                  <div className="news-date">{news.date}</div>
                  <h3 className="card-title">{news.title}</h3>
                  <p className="card-text">{news.excerpt}</p>
                  <Link to="/news" className="card-button">Читать полностью</Link>
                </div>
              </div>
            ))}
          </div>
          <div style={{textAlign: 'center', marginTop: '40px'}}>
            <Link to="/news" className="cta-button" style={{padding: '12px 30px'}}>Все новости</Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
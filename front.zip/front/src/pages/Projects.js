import React from 'react';

const Projects = () => {
  return (
    <div>
      <section className="hero" style={{background: 'linear-gradient(rgba(98, 167, 68, 0.8), rgba(98, 167, 68, 0.9))'}}>
        <div className="container">
          <h1 className="hero-title">Наши работы</h1>
        </div>
      </section>
      
      <section className="section">
        <div className="container">
          <h2 className="section-title">Текущие проекты</h2>
          <p>Информация о проектах появится скоро.</p>
        </div>
      </section>
    </div>
  );
};

export default Projects;
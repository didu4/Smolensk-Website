import React from 'react';

const Contacts = () => {
    return (
        <div>
            <section className="hero" style={{background: 'linear-gradient(rgba(98, 167, 68, 0.8), rgba(98, 167, 68, 0.9))'}}>
                <div className="container">
                    <h1 className="hero-title">Контакты</h1>
                    <p className="hero-subtitle">
                        Свяжитесь с нами удобным для вас способом
                    </p>
                </div>
            </section>

            <section className="section">
                <div className="container">
                    <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '40px'}}>
                        <div>
                            <h2 className="section-title">Наши контакты</h2>
                            <div style={{marginBottom: '20px'}}>
                                <h3>📞 Телефон</h3>
                                <p>+7 (4812) 33-99-69 - Приемная</p>
                                
                            </div>
                            
                            <div style={{marginBottom: '20px'}}>
                                <h3>✉️ Email</h3>
                                <p>ref@codd67.ru</p>
                            </div>
                            
                            <div style={{marginBottom: '20px'}}>
                                <h3>🏢 Адрес</h3>
                                <p>г. Смоленск, ул. Большая Краснофлотская, 70</p>
                                <p>Пн-Чт: 8:00-17:00</p>
                                <p>Пн-Пт: 8:00-15:00</p>
                            </div>
                            <div style={{marginBottom: '20px'}}>
                                <h3>Директор</h3>
                                <p>Гильденков Андрей Михайлович</p>
                                
                            </div>
                        </div>
                        
                        <div>
                            <h2 className="section-title">Обратная связь</h2>
                            <form style={{display: 'flex', flexDirection: 'column', gap: '15px'}}>
                                <input type="text" placeholder="Ваше имя" className="form-input" />
                                <input type="email" placeholder="Email" className="form-input" />
                                <input type="tel" placeholder="Телефон" className="form-input" />
                                <textarea placeholder="Сообщение" className="form-textarea"></textarea>
                                <button type="submit" className="submit-button">Отправить сообщение</button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Contacts;